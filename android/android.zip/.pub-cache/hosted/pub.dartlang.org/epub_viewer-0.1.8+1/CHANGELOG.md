## 0.1.8

* Bug fixes

## 0.0.8

* Display ios header.

## 0.0.6

* Display ios header.

## 0.0.4

* Updated documentation.

## 0.0.3

* Updated documentation.

## 0.0.2

* removed unwanted files to make plugin lighter.

## 0.0.1

* initial release.

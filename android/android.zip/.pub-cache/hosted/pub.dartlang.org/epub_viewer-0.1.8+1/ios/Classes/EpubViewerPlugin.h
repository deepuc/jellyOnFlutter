#import <Flutter/Flutter.h>

@interface EpubViewerPlugin : NSObject<FlutterPlugin>
@end

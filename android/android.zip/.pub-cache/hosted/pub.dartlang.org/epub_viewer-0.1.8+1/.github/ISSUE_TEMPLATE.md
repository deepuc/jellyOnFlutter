Issue / Feature -
Platform (android, iOS or both) -
Crash / Error - 

Steps to reproduce / Describe in detail - 
package com.example.epub_viewer_example.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

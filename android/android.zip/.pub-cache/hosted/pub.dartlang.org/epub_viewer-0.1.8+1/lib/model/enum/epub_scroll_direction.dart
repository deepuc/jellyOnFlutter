part of 'package:epub_viewer/epub_viewer.dart';

/// enum from scrollDirection to make it easier for users
enum EpubScrollDirection { HORIZONTAL, VERTICAL, ALLDIRECTIONS }

# video_player_example

Demonstrates how to use the video_player plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).

flutter format lib/
flutter format assets_audio_player_web/lib

git commit -am "formatted code"
git push
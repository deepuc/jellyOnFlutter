#import <Flutter/Flutter.h>

@interface AssetsAudioPlayerPlugin : NSObject<FlutterPlugin>
@end

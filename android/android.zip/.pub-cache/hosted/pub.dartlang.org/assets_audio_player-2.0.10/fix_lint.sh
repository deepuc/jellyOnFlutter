# when your edit don't want to autocomplete
rm -rf .idea/
rm -rf example/.idea/
rm -rf example/build/
rm -rf example/ios/.symlinks/
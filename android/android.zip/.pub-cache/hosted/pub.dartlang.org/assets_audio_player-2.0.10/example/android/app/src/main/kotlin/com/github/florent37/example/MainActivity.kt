package com.github.florent37.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

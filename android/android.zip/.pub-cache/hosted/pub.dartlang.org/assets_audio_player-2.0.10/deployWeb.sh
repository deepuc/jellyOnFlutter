cd example/
flutter build web
firebase deploy --debug

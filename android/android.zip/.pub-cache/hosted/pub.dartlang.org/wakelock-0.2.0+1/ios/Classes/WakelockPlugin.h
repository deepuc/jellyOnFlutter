#import <Flutter/Flutter.h>

@interface WakelockPlugin : NSObject<FlutterPlugin>
@end

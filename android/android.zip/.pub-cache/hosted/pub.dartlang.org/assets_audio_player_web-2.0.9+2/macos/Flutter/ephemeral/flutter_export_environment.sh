#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/florentchampigny/flutter/flutter-sdk"
export "FLUTTER_APPLICATION_PATH=/Users/florentchampigny/android/assets_audio_player/assets_audio_player_web"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_FRAMEWORK_DIR=/Users/florentchampigny/flutter/flutter-sdk/bin/cache/artifacts/engine/darwin-x64"
export "FLUTTER_BUILD_NAME=2.0.3"
export "FLUTTER_BUILD_NUMBER=2.0.3"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=false"
export "TREE_SHAKE_ICONS=false"

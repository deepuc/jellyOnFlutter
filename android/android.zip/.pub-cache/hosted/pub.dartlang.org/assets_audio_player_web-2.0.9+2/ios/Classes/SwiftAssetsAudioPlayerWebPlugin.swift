import Flutter
import UIKit

public class SwiftAssetsAudioPlayerWebPlugin: NSObject, FlutterPlugin {
  public static func register(with registrar: FlutterPluginRegistrar) {
    //no-op for compatibility
  }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
      //no-op for compatibility
  }
}
